from django.apps import AppConfig


class DriverRewardsAppConfig(AppConfig):
    name = 'driver_rewards_app'
