from django.shortcuts import render, redirect
from driver_rewards_app.models import *
from driver_rewards_app.keys import EBAY_APP_KEY
from django.urls import reverse_lazy, reverse
from django.views import generic
from .forms import RegisterForm, UpdateForm, UpdateFormDriver
from .models import Product, Order
from django.http import HttpResponseRedirect
from django.db.models import Q, Sum
import requests

def getNotifications(user):
    return Notification.objects.filter(user=user)

def RenderHomePage(request):
    context = { "user": request.user }
    return render(request, 'home.html', context)

class SignUp(generic.CreateView):
    form_class = RegisterForm
    success_url = reverse_lazy('login')
    template_name = 'signup.html'

def updateProfile(request, slug=None):
    user = request.user
    if request.user.is_driver:
        driver = request.user.driver
    if request.method == 'POST':
        form = UpdateForm(data=request.POST, instance=user)
        if request.user.is_driver:
            form2 = UpdateFormDriver(data=request.POST, instance=driver)
        if form.is_valid():
            user = form.save()
            if request.user.is_driver:
                driver = form2.save()
            return HttpResponseRedirect(reverse('profile'))
    else:
        form = UpdateForm(instance=user)
        context = {'form' : form}
        if request.user.is_driver:
            form2 = UpdateFormDriver(instance=driver)
            context = {'form' : form, 'form2' : form2}
        return render(request, 'updateProfile.html', context)

def Dashboard(request):
    if request.user.is_authenticated:
        if request.user.is_driver:
            context = { "driverUser": request.user,
                        "userOrgs": Relation.objects.filter(driver=request.user.driver),
                        "orders": Order.objects.filter(user=request.user.driver), 
                        "notifications": getNotifications(request.user)
                    }
            return render(request, 'driverDashboard.html', context)
        elif request.user.is_sponsor:
            context = { "sponsorUser": request.user }
            return render(request, 'sponsorDashboard.html', context)
        else:
            # Admin page/dashboard here
            context = { }
            return redirect('/admin/')
    else:
        # Redirect to Login
        return HttpResponseRedirect(reverse('login'))

def SponsorList(request):
    if request.user.is_authenticated:
        OrgList = Organization.objects.all()
        context = { "SponsorList": OrgList,
                    "User": request.user }
        return render(request, 'sponsorList.html', context)
    else:
        # Redirect to Login
        return HttpResponseRedirect(reverse('login'))


def OrderPage(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('login'))
    
    # Add check for "is_driver"

    driver = request.user.driver
    orders = Order.objects.filter(user=driver)
    context = { 
        'orders' : orders
    }
    return render(request, 'orders.html', context)

def SponsorApply(request, sponsor):
    if request.user.is_authenticated:
        if request.user.is_driver:
            context = { "driverUser": request.user,
                        "sponsor": sponsor }
            return render(request, 'apply.html', context)
        elif request.user.is_sponsor:
            return render(request, 'sponsorList.html', context={ "User": request.user })
    else:
        # Redirect to Login
        return HttpResponseRedirect(reverse('login'))
 
def ApplySend(request):
    if not request.user.is_authenticated:
        # Redirect to Login
        return HttpResponseRedirect(reverse('login'))
    
    if request.method == "POST":
        reason = request.POST.get('reason', None)
        driver = request.user.driver
        
        sponsorOrgName = request.POST.get('sponsorOrg', None)
        sponsorOrgObj = Organization.objects.get(name=sponsorOrgName)
        
        appObj = Application.objects.create(reason=reason, state='Pending')
        Relation.objects.create(driver=driver, organization=sponsorOrgObj, application=appObj, 
                                approved=False, points=0)

    # Return user to list of sponsors
    return redirect('/sponsors/')

def Applications(request):
    if not request.user.is_authenticated:
        # Redirect to Login
        return HttpResponseRedirect(reverse('login'))

    if request.user.is_sponsor:        
        context = { "AppList": Application.objects.filter(state='Pending')
                                .filter(relation__organization=request.user.sponsor.organization),
                    "User": request.user }

        return render(request, 'applicationList.html', context)
    else:
        # Only sponsors are allowed to see this page
        return redirect('/dashboard/')

def AcceptApply(request, appID):
    for app in Application.objects.filter(id=appID):
        app.state = 'Approved'
        app.save()

    return redirect('/applications/')

def DenyApply(request, appID):
    for app in Application.objects.filter(id=appID):
        app.state = 'D'
        app.save()
    
    return redirect('/applications/')

def usdToPoint(usd, organization):
    return usd * organization.point_value

def calculateCartCostUSD(relation):
    usd_price = relation.cart.all().aggregate(Sum('price')).get('price__sum', 0)
    if usd_price == None: 
        usd_price = 0
    return usd_price

def calculateCartCost(relation):
    usd_price = calculateCartCostUSD(relation)
    return usdToPoint(usd_price, relation.organization)

def AddItemToCart(request, sponsor):
    headers = {
        "Authorization":"Bearer " + EBAY_APP_KEY,
        "Content-Type":"application/json",
    }

    ebay_id = request.POST.get('ebayid', None)
    ebay_href = request.POST.get('ebayhref', None)
    sponsorOrg = Organization.objects.get(name=sponsor)
    driver = request.user.driver
    relation = Relation.objects.get(driver=driver, organization=sponsorOrg)

    response = requests.get(ebay_href, headers=headers).json()
    product = Product.objects.create(ebay_id=ebay_id, ebay_href=ebay_href, name=response['title'],price=response['price']['value'], organization=sponsorOrg)
    relation.cart.add(product)
    return redirect('sponsor_catalog', sponsor=sponsor)

def RemoveItemFromCart(request, sponsor):
    cart_item_id = request.POST.get('id', None)
    product_to_remove = Product.objects.get(id=cart_item_id)

    driver = request.user.driver
    sponsorOrg = Organization.objects.get(name=sponsor)
    relation = Relation.objects.get(driver=driver, organization=sponsorOrg)
    relation.cart.remove(product_to_remove)
    return redirect('sponsor_catalog', sponsor=sponsor)

def SponsorCatalog(request, sponsor):
    if not request.user.is_authenticated or request.user.driver == None:
        return HttpResponseRedirect(reverse('login'))
    
    sponsorOrgObj = Organization.objects.get(name=sponsor)
    sponsorQuery = sponsorOrgObj.product_filter_query_end
    sponsorFilters = sponsorOrgObj.product_filter_params
    driver = request.user.driver
    relation = Relation.objects.get(driver=driver, organization=sponsorOrgObj)

    headers = {
        "Authorization":"Bearer " + EBAY_APP_KEY,
        "Content-Type":"application/json",
    }

    # === CART ===
    cart_items = []
    for cart_item in relation.cart.all():
        #todo: make model master record
        response = requests.get(cart_item.ebay_href, headers=headers).json()
        item = {
            "id": cart_item.id,
            "title": response['title'],
            "price": response['price']['value'],
        }
        if 'image' in response.keys():
            item["image"] = response['image']['imageUrl']

        cart_items.append(item)

    # === Search ===
    searchTerm = request.GET.get('q', None)
    if searchTerm == None or searchTerm == '':
        searchTerm = 'drones'
    response = requests.get(f"https://api.ebay.com/buy/browse/v1/item_summary/search?q={searchTerm} {sponsorQuery}&{sponsorFilters}", headers=headers).json()

    cartCost = calculateCartCost(relation)
    context = {
        "response": response,
        "searchTerm": searchTerm,
        "cart": cart_items,
        "cart_cost": cartCost,
        "organization": sponsorOrgObj,
        "relation": relation,
    }
    return render(request, 'catalog.html', context)

def CreateOrg(request):
    if not request.user.is_authenticated:
        HttpResponseRedirect(reverse('login'))
        
    if request.user.is_sponsor:
        if request.method == 'GET':
            return render(request, 'createOrg.html')
        elif request.method == 'POST':
            orgName = request.POST.get('orgName')
            value = request.POST.get('pointValue')
            organization = Organization.objects.create(name=orgName, point_value=value,product_filter_query_end='',product_filter_params='')
            request.user.sponsor.organization = organization
            request.user.sponsor.save()
            return redirect('/dashboard/')
    else:
        return redirect('/dashboard/')

def Profile(request):
    if request.user.is_authenticated:
        if request.user.is_driver:
            context = {"driverUser" : request.user}
            return render(request, 'driverProfile.html', context)
        elif request.user.is_sponsor:
            context = {"sponsorUser" : request.user}
            return render(request, 'sponsorProfile.html', context)
        else:
            #just return to admin dashboard if possible
            return redirect('/admin/')
    else:
        return redirect('/dashboard/')
        
def DriverOrders(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('login'))
    if not request.user.is_sponsor:
        return redirect('/orders/')


    ######################################################
    # Currently grabs ALL orders marked as 'Pending'.
    # Should only grab orders created from their catalog.
    ######################################################
    orderList = Order.objects.filter(Q(status='Pending') | Q(status='P')).filter(user__relation__organization = request.user.sponsor.organization)
    context = { "orderList": orderList,
                "sponsorUser": request.user }

    return render(request, 'driverOrders.html', context)

def submitOrder(request, sponsor):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('login'))

    sponsorOrg = Organization.objects.get(name=sponsor)
    driver = request.user.driver
    relation = Relation.objects.get(driver=driver, organization=sponsorOrg)

    point_price = calculateCartCost(relation)
    
    if (point_price > relation.points):
        #TODO: let them know they do not have the points
        pass

    order = Order(user=driver, point_cost=calculateCartCost(relation), dollar_cost=calculateCartCostUSD(relation), address=driver.address)
    order.save()
    order.products.set(relation.cart.all())
    order.save()

    relation.cart.clear()
    relation.points -= point_price
    relation.save()

    return redirect('orders') 

def AcceptOrder(request, orderID):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('login'))
    if not request.user.is_sponsor:
        return redirect('/orders/')

    # Accept Order
    order = Order.objects.get(id=orderID)
    order.status = 'Approved'
    order.save()

    # Send notification to driver

    return redirect('/driverOrders/')

def DenyOrder(request, orderID):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('login'))
    if not request.user.is_sponsor:
        return redirect('/orders/')

    # Deny Order
    order = Order.objects.get(id=orderID)
    order.status = 'Denied'
    order.save()

    # Send notification to driver

    # Refund points

    return redirect('/driverOrders/')

def ModifyOrder(request, orderID):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('login'))

    order = Order.objects.get(id=orderID)
    if order.status == 'Pending' or order.status == 'P':
        context = { "order": Order.objects.get(id=orderID) }
        return render(request, 'modifyOrder.html', context)

    return redirect('/orders/')

def EnterOrderInfo(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('login'))

    if request.method == 'POST':
        order = Order.objects.get(id=request.POST.get('order'))
        order.address = request.POST.get('shipAddr')
        order.save()

    return redirect('/orders/')

def CancelOrder(request, orderID):
    if not request.user.is_authenticated:
        HttpResponseRedirect(reverse('login'))

    order = Order.objects.get(id=orderID)

    if order.status == 'Pending' or order.status == 'P':
        order.status = 'Cancelled'
        order.save()
        
        # Refund points

    return redirect('/orders/')

# Set to access across password change views
globalUserObj = None

def ForgotPassword(request, wrongUsername):
    if request.user.is_staff:
        return redirect('/admin/')

    if wrongUsername == "True":
        wrong = True
    else:
        wrong = False

    context = { "user": request.user,
                "wrongUsername": wrong }
    # redirect to page where they enter username
    return render(request, 'enterUsername.html', context)
    
def GetAnswers(request, wrongAnswers):
    if request.user.is_staff:
        return redirect('/admin/')

    if request.method == 'POST':
        # Check if valid username
        if not User.objects.filter(username=request.POST.get('username')).exists():
            return redirect('/forgotPass/True/')
        
        userObj = User.objects.get(username=request.POST.get('username'))
        
        global globalUserObj
        globalUserObj = userObj

        if wrongAnswers == "True":
            wrong = True
        else:
            wrong = False
        
        context = { "user": userObj,
                    "wrongAnswers": wrong }
        return render(request, 'answerSecQuestions.html', context)
    else:
        if wrongAnswers == "True":
            wrong = True
        else:
            wrong = False

        context = { "user": globalUserObj,
                    "wrongAnswers": wrong }

        return render(request, 'answerSecQuestions.html', context)

def CheckAnswers(request):
    if request.user.is_staff:
        return redirect('/admin/')

    if request.method == 'POST':
        givenAnswer1 = request.POST.get('secAnswer1')
        givenAnswer2 = request.POST.get('secAnswer2')
        userObj = User.objects.get(username=request.POST.get('userObj'))
        checkAnswer1 = userObj.security_Answer_1
        checkAnswer2 = userObj.security_Answer_2

        if givenAnswer1 == checkAnswer1 and givenAnswer2 == checkAnswer2:
            context = { "user": request.user,
                        "noMatch": False }
            return render(request, 'resetPassword.html', context)
        else:
            #context = { "user": userObj,
            #            "wrongAnswers": True }
            #return render(request, 'answerSecQuestions.html', context)
            
            return redirect('/answerQuestions/True/')
    else:
        return redirect('/forgotPass/False/')

def ResetPassword(request):
    if request.user.is_staff:
        return redirect('/admin/')
    
    if request.method == 'POST':
        pass1 = request.POST.get('newPass1')
        pass2 = request.POST.get('newPass2')

        if pass1 != pass2:
            context = { "user": request.user,
                        "noMatch": True }
            return render(request, 'resetPassword.html', context)
        else:
            global globalUserObj
            globalUserObj.set_password(pass1)
            globalUserObj.save()
        
        return redirect('/accounts/login/')
    else:
        return redirect('/forgotPass/False/')
        


    