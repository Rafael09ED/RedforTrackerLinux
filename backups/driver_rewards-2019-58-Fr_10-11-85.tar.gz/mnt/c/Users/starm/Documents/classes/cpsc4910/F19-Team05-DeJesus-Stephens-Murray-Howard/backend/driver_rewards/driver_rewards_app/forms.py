from django.contrib.auth import get_user_model
from .models import Driver
from django.contrib.auth.forms import UserCreationForm, UserChangeForm


class RegisterForm(UserCreationForm):
    class Meta:
        model = get_user_model()
        fields = ('first_name', 'last_name', 'username', 'email', 'is_sponsor', 'is_driver', 'security_Question_1', 'security_Answer_1', 'security_Question_2', 'security_Answer_2')
        
class UpdateForm(UserChangeForm):
    class Meta:
        model = get_user_model()
        fields = ('first_name', 'last_name', 'username', 'email')

class UpdateFormDriver(UserChangeForm):
    class Meta:
        model = Driver
        fields = ('address',)
