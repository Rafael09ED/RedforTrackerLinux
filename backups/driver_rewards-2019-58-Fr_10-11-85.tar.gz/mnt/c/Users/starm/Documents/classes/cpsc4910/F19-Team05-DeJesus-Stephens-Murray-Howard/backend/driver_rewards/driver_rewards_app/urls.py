from django.urls import path
from django.views.generic.base import TemplateView
from django.contrib import admin
from driver_rewards_app import views

urlpatterns = [
    path('accounts/signup/', views.SignUp.as_view(), name='signup'),
    path('', views.RenderHomePage),
    path('dashboard/', views.Dashboard),
    path('sponsors/', views.SponsorList),
    path('sponsors/<sponsor>/catalog/', views.SponsorCatalog, name='sponsor_catalog'),
    path('sponsors/<sponsor>/catalog/cart/add/', views.AddItemToCart),
    path('sponsors/<sponsor>/catalog/cart/remove/', views.RemoveItemFromCart),
    path('orders/', views.OrderPage, name="orders"),
    path('orders/<sponsor>/submit/', views.submitOrder),
    path('sponsors/apply/<sponsor>/', views.SponsorApply),
    path('applySend/', views.ApplySend),
    path('applications/', views.Applications),
    path('applications/accept/<appID>/', views.AcceptApply),
    path('applications/deny/<appID>/', views.DenyApply),
    path('createorg/', views.CreateOrg),
    path('dashboard/profile/', views.Profile, name='profile'),
    path('dashboard/profile/update/', views.updateProfile),
    path('driverOrders/', views.DriverOrders),
    path('driverOrders/accept/<orderID>/', views.AcceptOrder),
    path('driverOrders/deny/<orderID>/', views.DenyOrder),
    path('driverOrders/modify/<orderID>/', views.ModifyOrder),
    path('orders/cancel/<orderID>/', views.CancelOrder),
    path('orders/modify/<orderID>/', views.ModifyOrder),
    path('forgotPass/<wrongUsername>/', views.ForgotPassword),
    path('answerQuestions/<wrongAnswers>/', views.GetAnswers),
    path('checkAnswers/', views.CheckAnswers),
    path('resetPassword/', views.ResetPassword),
    path('enterOrderInfo/', views.EnterOrderInfo)
]