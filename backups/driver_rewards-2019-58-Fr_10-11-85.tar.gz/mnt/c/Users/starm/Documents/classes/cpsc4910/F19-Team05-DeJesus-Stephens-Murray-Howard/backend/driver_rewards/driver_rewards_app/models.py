from django.db import models
from django.contrib.auth.models import AbstractUser
from fernet_fields import EncryptedCharField

class Organization(models.Model):
    name = models.CharField(max_length=100)
    point_value = models.IntegerField()
    product_filter_query_end = models.CharField(max_length=100, blank=True)
    product_filter_params = models.CharField(max_length=100, blank=True)

class User(AbstractUser):
    is_sponsor = models.BooleanField(null=True)
    is_driver = models.BooleanField(null=True)
    security_Question_1 = models.CharField(max_length=1000)
    security_Answer_1 = EncryptedCharField(max_length=1000)
    security_Question_2 = models.CharField(max_length=1000)
    security_Answer_2 = EncryptedCharField(max_length=1000)

    # user is_driver or is_sponsor shouldn't change so I don't need to delete and related one-to-one models
    def save(self, *args, **kwargs):
        super(User, self).save(*args, **kwargs)
        if getattr(self, 'is_sponsor', False) and not hasattr(self, 'sponsor'):
            s = Sponsor(user=self, organization=None, permissions=0)
            s.save()
        if getattr(self, 'is_driver', False) and not hasattr(self, 'driver'):
            d = Driver(user=self, address="")
            d.save()
        

class Admin(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

class Sponsor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, null=True)
    permissions = models.IntegerField()

class Driver(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.TextField()

class Product(models.Model):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE)
    ebay_id = models.CharField(max_length=50)
    ebay_href =  models.CharField(max_length=120)
    name = models.CharField(max_length=120)
    price = models.DecimalField(max_digits=8, decimal_places=2)

class Order(models.Model):
    user = models.ForeignKey(Driver, on_delete=models.CASCADE)
    products = models.ManyToManyField(Product)
    address = models.CharField(max_length=100)
    ORDER_STATES = (
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('D', 'Denied'),
        ('C', 'Cancelled'),
    )
    status = models.CharField(max_length=100, choices=ORDER_STATES, default='Pending')
    point_cost = models.IntegerField()
    dollar_cost = models.FloatField(max_length=100)
    timestamp = models.DateTimeField(auto_now=True)
    # state = models.CharField(max_length=10, choices=ORDER_STATES, default='Pending')

class Application(models.Model):
    APP_STATES = (
        ('P', 'Pending'),
        ('A', 'Approved'),
        ('D', 'Denied'),
    )
    reason = models.CharField(max_length=1000)
    state = models.CharField(max_length=10, choices=APP_STATES, default='Pending')

class Relation(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE)
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE)
    approved = models.BooleanField()
    points = models.IntegerField()
    cart = models.ManyToManyField(Product, blank=True)
    application = models.OneToOneField(Application, on_delete=models.CASCADE, null=True)

class Notification(models.Model):
    title = models.CharField(max_length=200)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.CharField(max_length=200, blank=True, null=True)
    url = models.CharField(max_length=300, blank=True, null=True)