from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Organization)
admin.site.register(Sponsor)
admin.site.register(Driver)
admin.site.register(Relation)
admin.site.register(Order)
admin.site.register(Product)
admin.site.register(User)
admin.site.register(Application)
admin.site.register(Notification)
